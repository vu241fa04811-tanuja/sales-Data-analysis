"""
Sales Data Analysis - Main Application
Complete sales analysis and visualization pipeline
"""

import os
import sys
from sales_analyzer import SalesAnalyzer
from sales_visualizer import SalesVisualizer


def main():
    """Main function to run the complete sales analysis"""
    
    print("\n" + "="*70)
    print(" "*20 + "SALES DATA ANALYSIS SYSTEM")
    print("="*70 + "\n")
    
    # Configuration
    data_file = 'data/sales_data.csv'
    output_dir = 'output'
    
    # Check if data file exists
    if not os.path.exists(data_file):
        print(f"✗ Error: Data file not found - {data_file}")
        print("  Please ensure the sales data CSV file exists in the 'data' directory.")
        sys.exit(1)
    
    # Step 1: Analyze the data
    print("📊 Step 1: Analyzing Sales Data...")
    print("-" * 70)
    
    analyzer = SalesAnalyzer(data_file)
    metrics = analyzer.analyze()
    
    if metrics is None:
        print("\n✗ Analysis failed. Please check the data file and try again.")
        sys.exit(1)
    
    # Step 2: Get product summary
    product_summary = analyzer.get_product_summary()
    summary_dict = analyzer.get_summary_dict()
    
    # Step 3: Create visualizations
    print("\n📈 Step 2: Generating Visualizations...")
    print("-" * 70)
    
    visualizer = SalesVisualizer(output_dir)
    
    # Generate daily sales chart
    print("\n  Creating daily sales bar chart...")
    daily_chart = visualizer.create_daily_sales_chart(summary_dict['daily_sales'])
    
    # Generate product sales chart
    print("  Creating product sales chart...")
    product_chart = visualizer.create_product_sales_chart(product_summary)
    
    # Generate comprehensive dashboard
    print("  Creating comprehensive dashboard...")
    dashboard = visualizer.create_dashboard(summary_dict, product_summary)
    
    # Step 4: Summary
    print("\n" + "="*70)
    print("✓ ANALYSIS COMPLETE!")
    print("="*70)
    print(f"\n📁 Output files saved to: {os.path.abspath(output_dir)}/")
    print(f"   • Daily Sales Chart: {os.path.basename(daily_chart)}")
    print(f"   • Product Sales Chart: {os.path.basename(product_chart)}")
    print(f"   • Sales Dashboard: {os.path.basename(dashboard)}")
    
    print("\n💡 Manager Insights:")
    print("-" * 70)
    
    total_revenue = summary_dict['total_revenue']
    total_products = summary_dict['total_products_sold']
    top_product = summary_dict['top_selling_product']
    daily_sales = summary_dict['daily_sales']
    
    avg_daily_sales = total_revenue / len(daily_sales) if len(daily_sales) > 0 else 0
    best_day = daily_sales.idxmax()
    best_day_sales = daily_sales.max()
    worst_day = daily_sales.idxmin()
    worst_day_sales = daily_sales.min()
    
    print(f"   • Overall Performance: ₹{total_revenue:,.2f} revenue from {int(total_products):,} units")
    print(f"   • Star Product: {top_product['name']} generated ₹{top_product['revenue']:,.2f}")
    print(f"   • Daily Average: ₹{avg_daily_sales:,.2f} per day")
    print(f"   • Best Day: {best_day.strftime('%Y-%m-%d')} with ₹{best_day_sales:,.2f}")
    print(f"   • Weakest Day: {worst_day.strftime('%Y-%m-%d')} with ₹{worst_day_sales:,.2f}")
    
    # Calculate trend
    if len(daily_sales) >= 2:
        first_half = daily_sales[:len(daily_sales)//2].mean()
        second_half = daily_sales[len(daily_sales)//2:].mean()
        trend = "📈 Upward" if second_half > first_half else "📉 Downward"
        change_pct = ((second_half - first_half) / first_half) * 100
        print(f"   • Sales Trend: {trend} ({change_pct:+.1f}% change)")
    
    print("\n" + "="*70)
    print("Thank you for using Sales Data Analysis System!")
    print("="*70 + "\n")


if __name__ == "__main__":
    main()
