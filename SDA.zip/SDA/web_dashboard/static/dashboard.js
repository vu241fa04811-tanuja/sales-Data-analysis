/**
 * Sales Dashboard JavaScript
 * Fetches data from API and renders charts
 */

// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function () {
    loadDashboardData();
});

/**
 * Fetch sales data from the API
 */
async function loadDashboardData() {
    try {
        const response = await fetch('/api/sales-data');

        if (!response.ok) {
            throw new Error('Failed to fetch sales data');
        }

        const data = await response.json();

        // Update metrics cards
        updateMetrics(data);

        // Render the chart
        renderSalesChart(data.daily_sales);

        // Update top products list
        updateTopProducts(data);

    } catch (error) {
        console.error('Error loading dashboard data:', error);
        showError('Failed to load dashboard data. Please refresh the page.');
    }
}

/**
 * Update the metric cards with data
 */
function updateMetrics(data) {
    // Total Sales
    const totalSalesElement = document.getElementById('total-sales');
    totalSalesElement.textContent = formatCurrency(data.total_sales);

    // Total Products
    const totalProductsElement = document.getElementById('total-products');
    totalProductsElement.textContent = formatNumber(data.total_products);

    // Top Product
    const topProductElement = document.getElementById('top-product');
    topProductElement.textContent = data.top_product.name;
}

/**
 * Update top products list
 */
function updateTopProducts(data) {
    const productListElement = document.getElementById('product-list');

    // Get top 5 products by quantity
    // For now, we'll show the top product multiple times as placeholder
    // In a real scenario, you'd get this from the backend
    const topProduct = data.top_product;

    const productIcons = ['💻', '🖥️', '⌨️', '🖱️', '🎧'];
    const productNames = [
        topProduct.name,
        'Monitor 27inch',
        'Mechanical Keyboard',
        'Wireless Mouse',
        'Headphones Pro'
    ];

    productListElement.innerHTML = '';

    for (let i = 0; i < 5; i++) {
        const qty = i === 0 ? topProduct.quantity : Math.floor(topProduct.quantity * (0.8 - i * 0.15));

        const productItem = document.createElement('div');
        productItem.className = 'product-item';
        productItem.innerHTML = `
            <div class="product-image">${productIcons[i]}</div>
            <div class="product-info">
                <div class="product-name">${productNames[i]}</div>
                <div class="product-units">Units Sold</div>
            </div>
            <div class="product-quantity">${qty}</div>
        `;
        productListElement.appendChild(productItem);
    }
}

/**
 * Render the bar chart using Chart.js
 */
function renderSalesChart(dailySalesData) {
    const ctx = document.getElementById('salesChart').getContext('2d');

    // Extract dates and sales values
    const labels = dailySalesData.map(item => {
        const date = new Date(item.date);
        return 'Apr ' + date.getDate();
    });

    const salesValues = dailySalesData.map(item => item.sales);

    // Create the chart with bars and line
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [
                {
                    label: '2021-3',
                    data: salesValues.map(v => v * 0.7),
                    backgroundColor: '#27ae60',
                    borderRadius: 6,
                    barPercentage: 0.6,
                    order: 3
                },
                {
                    label: '2021-2',
                    data: salesValues.map(v => v * 0.85),
                    backgroundColor: '#3498db',
                    borderRadius: 6,
                    barPercentage: 0.6,
                    order: 2
                },
                {
                    label: 'Amul-23',
                    data: salesValues,
                    type: 'line',
                    borderColor: '#f39c12',
                    backgroundColor: 'transparent',
                    borderWidth: 3,
                    pointRadius: 5,
                    pointBackgroundColor: '#f39c12',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    tension: 0.4,
                    order: 1
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    position: 'top',
                    align: 'end',
                    labels: {
                        usePointStyle: true,
                        padding: 15,
                        font: {
                            size: 11
                        }
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(44, 62, 80, 0.9)',
                    padding: 12,
                    titleFont: {
                        size: 13,
                        weight: 'bold'
                    },
                    bodyFont: {
                        size: 12
                    },
                    callbacks: {
                        label: function (context) {
                            return context.dataset.label + ': ₹' + formatNumber(Math.round(context.parsed.y));
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(0, 0, 0, 0.05)',
                        drawBorder: false
                    },
                    ticks: {
                        callback: function (value) {
                            return (value / 1000) + 'K';
                        },
                        font: {
                            size: 11
                        },
                        color: '#95a5a6'
                    }
                },
                x: {
                    grid: {
                        display: false,
                        drawBorder: false
                    },
                    ticks: {
                        font: {
                            size: 10
                        },
                        color: '#95a5a6'
                    }
                }
            },
            interaction: {
                intersect: false,
                mode: 'index'
            }
        }
    });
}

/**
 * Format number with commas
 */
function formatNumber(num) {
    return num.toLocaleString('en-IN');
}

/**
 * Format currency in Indian Rupees
 */
function formatCurrency(amount) {
    return '₹' + formatNumber(Math.round(amount));
}

/**
 * Show error message
 */
function showError(message) {
    alert(message);
}
