# Sales Dashboard Web Application

A simple, clean web-based sales dashboard for managers to view sales analytics with authentication and interactive charts.

## 🎯 Features

- **Manager Authentication** - Secure login with predefined credentials
- **Sales Metrics** - Total sales, total products sold, top-selling product, average daily sales
- **Interactive Chart** - Bar chart showing day-by-day sales trends for the entire month
- **Clean UI** - Modern design with gradients and smooth animations (no frameworks)
- **Responsive** - Works on desktop and mobile devices

## 📁 Project Structure

```
web_dashboard/
├── app.py                      # Flask backend application
├── sales_data_web.csv          # Sample dataset (30 days, 120 records)
├── requirements_web.txt        # Python dependencies
├── templates/
│   ├── login.html             # Login page
│   └── dashboard.html         # Dashboard page
└── static/
    ├── style.css              # All CSS styling
    └── dashboard.js           # JavaScript for data fetching and charts
```

## 🚀 Quick Start

### 1. Install Dependencies

```bash
cd web_dashboard
pip install -r requirements_web.txt
```

This installs:
- Flask (web framework)
- pandas (data processing)

### 2. Run the Application

```bash
python app.py
```

You should see:
```
Sales Dashboard Web Application
============================================================

Login Credentials:
  Username: manager
  Password: admin123

Access the application at: http://127.0.0.1:5000
============================================================
```

### 3. Access the Dashboard

1. Open your browser and go to: **http://127.0.0.1:5000**
2. Login with:
   - **Username:** `manager`
   - **Password:** `admin123`
3. View your sales dashboard!

## 📊 Dataset

The `sales_data_web.csv` file contains **120 records** spanning **30 days** (January 2026) with the following columns:

- `date` - Date of sale (YYYY-MM-DD)
- `product_name` - Name of the product
- `category` - Product category (Electronics, Accessories, Peripherals)
- `quantity` - Number of units sold
- `unit_price` - Price per unit (₹)
- `total_price` - Total sale amount (₹)

**Sample Products:**
- Laptop Pro 15 (₹45,000)
- Monitor 27inch (₹18,000)
- Mechanical Keyboard (₹2,500)
- Wireless Mouse (₹800)
- Headphones Pro (₹3,500)
- And more...

## 🔧 How It Works

### Backend (Flask)

**app.py** handles:

1. **Routes:**
   - `/` - Redirects to login or dashboard
   - `/login` - Login page and authentication
   - `/dashboard` - Dashboard page (requires authentication)
   - `/api/sales-data` - JSON API endpoint for metrics
   - `/logout` - Clears session

2. **Authentication:**
   - Session-based authentication
   - Predefined credentials (username: `manager`, password: `admin123`)
   - Login required decorator for protected routes

3. **Data Processing:**
   - Loads CSV using pandas
   - Calculates total sales, total products, top product
   - Aggregates daily sales for the chart
   - Returns JSON to frontend

### Frontend

**login.html:**
- Simple login form with username and password
- Error message display for invalid credentials
- Modern gradient background with glassmorphism effect

**dashboard.html:**
- Header with welcome message and logout button
- 4 metric cards displaying key statistics
- Chart section with Canvas element for Chart.js
- Loads data dynamically via JavaScript

**style.css:**
- Clean, modern styling without any frameworks
- Gradient backgrounds and smooth animations
- Responsive grid layout for metrics
- Mobile-friendly design

**dashboard.js:**
- Fetches data from `/api/sales-data` endpoint
- Updates metric cards with formatted values
- Renders bar chart using Chart.js library (loaded via CDN)
- Formats currency in Indian Rupees (₹)

## 🎨 Customization

### Change Login Credentials

Edit `app.py`:
```python
MANAGER_CREDENTIALS = {
    'username': 'your_username',
    'password': 'your_password'
}
```

### Use Your Own Data

Replace `sales_data_web.csv` with your data. Ensure it has these columns:
- `date`
- `product_name`
- `category`
- `quantity`
- `unit_price`
- `total_price`

### Modify Colors

Edit `static/style.css`:
```css
/* Change gradient colors */
background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
```

### Add More Metrics

1. Calculate new metric in `app.py` (in `load_and_process_data()`)
2. Add to JSON response
3. Create new metric card in `dashboard.html`
4. Update JavaScript in `dashboard.js` to display it

## 🌐 File Connections

```
Browser Request
    ↓
Flask Routes (app.py)
    ↓
Templates (login.html / dashboard.html)
    ↓
Static Files (style.css / dashboard.js)
    ↓
API Call (/api/sales-data)
    ↓
Data Processing (pandas)
    ↓
CSV File (sales_data_web.csv)
    ↓
JSON Response
    ↓
Chart.js Rendering
```

## 📱 Screenshots

### Login Page
- Clean centered card with gradient background
- Username and password fields
- Error message display

### Dashboard
- Header with logout button
- 4 metric cards with icons
- Interactive bar chart showing 30 days of sales

## 🔒 Security Notes

**For Demo/Development Only:**
- Credentials are hardcoded
- Secret key should be changed
- No password hashing
- No HTTPS

**For Production:**
- Use environment variables for credentials
- Implement proper password hashing (bcrypt)
- Use a database instead of CSV
- Enable HTTPS
- Add CSRF protection
- Implement rate limiting

## 🛠️ Technologies Used

- **Backend:** Python 3.8+, Flask 3.0+
- **Data Processing:** pandas 2.0+
- **Frontend:** HTML5, CSS3, JavaScript (ES6+)
- **Charts:** Chart.js 4.4.0 (via CDN)
- **No frameworks:** Pure CSS, no Bootstrap or Tailwind

## 📝 API Endpoint

**GET /api/sales-data** (requires authentication)

Returns:
```json
{
  "total_sales": 9876543.21,
  "total_products": 1234,
  "top_product": {
    "name": "Laptop Pro 15",
    "quantity": 189
  },
  "daily_sales": [
    {"date": "2026-01-01", "sales": 182600},
    {"date": "2026-01-02", "sales": 229400},
    ...
  ]
}
```

## 🎓 Learning Points

This project demonstrates:
- Flask routing and session management
- CSV data processing with pandas
- RESTful API design
- Modern CSS without frameworks
- Chart.js integration
- Responsive web design
- Client-server architecture

## 🤝 Support

For issues or questions:
1. Check that Flask is running on port 5000
2. Verify CSV file exists in the same directory as app.py
3. Check browser console for JavaScript errors
4. Ensure pandas and Flask are installed

---

**Built for:** Quick sales analytics demo  
**Purpose:** Manager dashboard with authentication and visualization  
**Level:** Beginner to Intermediate Flask
