"""
Sales Dashboard Web Application - Flask Backend
Handles authentication, data processing, and API endpoints
"""

from flask import Flask, render_template, request, redirect, url_for, session, jsonify
import pandas as pd
import os
from functools import wraps

app = Flask(__name__)
app.secret_key = 'your-secret-key-change-in-production'  # Change this in production

# Predefined manager credentials
MANAGER_CREDENTIALS = {
    'username': 'manager',
    'password': 'admin123'
}

# Path to the sales data CSV
DATA_FILE = 'sales_data_web.csv'


def login_required(f):
    """Decorator to require login for routes"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'logged_in' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function


def load_and_process_data():
    """Load CSV data and calculate metrics"""
    try:
        # Load the CSV file
        df = pd.read_csv(DATA_FILE)
        
        # Convert date column to datetime
        df['date'] = pd.to_datetime(df['date'])
        
        # Calculate metrics
        total_sales = df['total_price'].sum()
        total_products = df['quantity'].sum()
        
        # Find top-selling product by quantity
        product_quantities = df.groupby('product_name')['quantity'].sum()
        top_product = product_quantities.idxmax()
        top_product_quantity = product_quantities.max()
        
        # Calculate daily sales
        daily_sales = df.groupby('date')['total_price'].sum().sort_index()
        
        # Format daily sales for Chart.js
        daily_sales_data = [
            {
                'date': date.strftime('%Y-%m-%d'),
                'sales': float(sales)
            }
            for date, sales in daily_sales.items()
        ]
        
        return {
            'total_sales': float(total_sales),
            'total_products': int(total_products),
            'top_product': {
                'name': top_product,
                'quantity': int(top_product_quantity)
            },
            'daily_sales': daily_sales_data
        }
        
    except Exception as e:
        print(f"Error loading data: {str(e)}")
        return None


@app.route('/')
def index():
    """Redirect to login or dashboard based on session"""
    if 'logged_in' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))


@app.route('/login', methods=['GET', 'POST'])
def login():
    """Handle login page and authentication"""
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        # Validate credentials
        if (username == MANAGER_CREDENTIALS['username'] and 
            password == MANAGER_CREDENTIALS['password']):
            session['logged_in'] = True
            session['username'] = username
            return redirect(url_for('dashboard'))
        else:
            return render_template('login.html', error='Invalid username or password')
    
    # If already logged in, redirect to dashboard
    if 'logged_in' in session:
        return redirect(url_for('dashboard'))
    
    return render_template('login.html')


@app.route('/dashboard')
@login_required
def dashboard():
    """Display the sales dashboard"""
    return render_template('dashboard.html', username=session.get('username'))


@app.route('/api/sales-data')
@login_required
def get_sales_data():
    """API endpoint to get sales data as JSON"""
    data = load_and_process_data()
    
    if data is None:
        return jsonify({'error': 'Failed to load data'}), 500
    
    return jsonify(data)


@app.route('/logout')
def logout():
    """Clear session and redirect to login"""
    session.clear()
    return redirect(url_for('login'))


if __name__ == '__main__':
    # Check if data file exists
    if not os.path.exists(DATA_FILE):
        print(f"Warning: Data file '{DATA_FILE}' not found!")
        print("Please ensure the CSV file is in the same directory as app.py")
    
    print("\n" + "="*60)
    print("Sales Dashboard Web Application")
    print("="*60)
    print(f"\nLogin Credentials:")
    print(f"  Username: {MANAGER_CREDENTIALS['username']}")
    print(f"  Password: {MANAGER_CREDENTIALS['password']}")
    print(f"\nAccess the application at: http://127.0.0.1:5000")
    print("="*60 + "\n")
    
    app.run(debug=True, host='127.0.0.1', port=5000)
