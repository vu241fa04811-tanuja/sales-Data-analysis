"""
Sales Data Visualization Module
Creates charts and visual reports for sales analysis
"""

import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import pandas as pd
import os
from datetime import datetime


class SalesVisualizer:
    """Class for creating sales data visualizations"""
    
    def __init__(self, output_dir='output'):
        """
        Initialize the visualizer
        
        Args:
            output_dir: Directory to save generated charts
        """
        self.output_dir = output_dir
        
        # Create output directory if it doesn't exist
        os.makedirs(output_dir, exist_ok=True)
        
        # Set style for better-looking charts
        plt.style.use('seaborn-v0_8-darkgrid')
        
    def create_daily_sales_chart(self, daily_sales, save_path=None):
        """
        Create a bar chart for daily sales
        
        Args:
            daily_sales: Pandas Series with date index and sales values
            save_path: Optional path to save the chart
        """
        if save_path is None:
            save_path = os.path.join(self.output_dir, 'daily_sales_chart.png')
        
        # Create figure and axis
        fig, ax = plt.subplots(figsize=(14, 6))
        
        # Create bar chart
        dates = daily_sales.index
        sales = daily_sales.values
        
        bars = ax.bar(dates, sales, color='#2E86AB', alpha=0.8, edgecolor='#1A5276', linewidth=1.5)
        
        # Customize the chart
        ax.set_xlabel('Date', fontsize=12, fontweight='bold')
        ax.set_ylabel('Total Sales (₹)', fontsize=12, fontweight='bold')
        ax.set_title('Day-wise Sales Trend', fontsize=16, fontweight='bold', pad=20)
        
        # Format y-axis to show currency
        ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, p: f'₹{x:,.0f}'))
        
        # Format x-axis dates
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%m-%d'))
        plt.xticks(rotation=45, ha='right')
        
        # Add value labels on top of bars
        for bar in bars:
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height,
                   f'₹{height:,.0f}',
                   ha='center', va='bottom', fontsize=8, fontweight='bold')
        
        # Add grid for better readability
        ax.grid(axis='y', alpha=0.3, linestyle='--')
        
        # Tight layout to prevent label cutoff
        plt.tight_layout()
        
        # Save the chart
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"✓ Daily sales chart saved to: {save_path}")
        
        plt.close()
        
        return save_path
    
    def create_product_sales_chart(self, product_summary, save_path=None):
        """
        Create a horizontal bar chart for product-wise sales
        
        Args:
            product_summary: DataFrame with product sales data
            save_path: Optional path to save the chart
        """
        if save_path is None:
            save_path = os.path.join(self.output_dir, 'product_sales_chart.png')
        
        # Create figure and axis
        fig, ax = plt.subplots(figsize=(12, 6))
        
        # Sort by total sales
        product_summary = product_summary.sort_values('total_sales', ascending=True)
        
        # Create horizontal bar chart
        products = product_summary.index
        sales = product_summary['total_sales']
        
        bars = ax.barh(products, sales, color='#A23B72', alpha=0.8, edgecolor='#6B1E49', linewidth=1.5)
        
        # Customize the chart
        ax.set_xlabel('Total Sales (₹)', fontsize=12, fontweight='bold')
        ax.set_ylabel('Product', fontsize=12, fontweight='bold')
        ax.set_title('Product-wise Sales Performance', fontsize=16, fontweight='bold', pad=20)
        
        # Format x-axis to show currency
        ax.xaxis.set_major_formatter(plt.FuncFormatter(lambda x, p: f'₹{x:,.0f}'))
        
        # Add value labels at the end of bars
        for bar in bars:
            width = bar.get_width()
            ax.text(width, bar.get_y() + bar.get_height()/2.,
                   f'₹{width:,.0f}',
                   ha='left', va='center', fontsize=10, fontweight='bold', 
                   bbox=dict(boxstyle='round,pad=0.3', facecolor='white', alpha=0.7))
        
        # Add grid for better readability
        ax.grid(axis='x', alpha=0.3, linestyle='--')
        
        # Tight layout
        plt.tight_layout()
        
        # Save the chart
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"✓ Product sales chart saved to: {save_path}")
        
        plt.close()
        
        return save_path
    
    def create_dashboard(self, metrics, product_summary, save_path=None):
        """
        Create a comprehensive dashboard with multiple visualizations
        
        Args:
            metrics: Dictionary containing analysis metrics
            product_summary: DataFrame with product sales data
            save_path: Optional path to save the dashboard
        """
        if save_path is None:
            save_path = os.path.join(self.output_dir, 'sales_dashboard.png')
        
        # Create figure with subplots
        fig = plt.figure(figsize=(16, 10))
        gs = fig.add_gridspec(3, 2, hspace=0.3, wspace=0.3)
        
        # Title for the dashboard
        fig.suptitle('Sales Performance Dashboard', fontsize=20, fontweight='bold', y=0.98)
        
        # 1. Daily Sales Trend (top, spanning both columns)
        ax1 = fig.add_subplot(gs[0, :])
        daily_sales = metrics.get('daily_sales', pd.Series())
        
        if not daily_sales.empty:
            dates = daily_sales.index
            sales = daily_sales.values
            bars = ax1.bar(dates, sales, color='#2E86AB', alpha=0.8, edgecolor='#1A5276', linewidth=1.5)
            ax1.set_xlabel('Date', fontsize=10, fontweight='bold')
            ax1.set_ylabel('Sales (₹)', fontsize=10, fontweight='bold')
            ax1.set_title('Daily Sales Trend', fontsize=14, fontweight='bold')
            ax1.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, p: f'₹{x:,.0f}'))
            ax1.xaxis.set_major_formatter(mdates.DateFormatter('%m-%d'))
            plt.setp(ax1.xaxis.get_majorticklabels(), rotation=45, ha='right')
            ax1.grid(axis='y', alpha=0.3, linestyle='--')
        
        # 2. Product Sales (middle left)
        ax2 = fig.add_subplot(gs[1, 0])
        if product_summary is not None and not product_summary.empty:
            sorted_products = product_summary.sort_values('total_sales', ascending=True)
            products = sorted_products.index
            sales = sorted_products['total_sales']
            bars = ax2.barh(products, sales, color='#A23B72', alpha=0.8, edgecolor='#6B1E49', linewidth=1.5)
            ax2.set_xlabel('Sales (₹)', fontsize=10, fontweight='bold')
            ax2.set_title('Product-wise Sales', fontsize=14, fontweight='bold')
            ax2.xaxis.set_major_formatter(plt.FuncFormatter(lambda x, p: f'₹{x/1000:.0f}K'))
            ax2.grid(axis='x', alpha=0.3, linestyle='--')
        
        # 3. Key Metrics Summary (middle right)
        ax3 = fig.add_subplot(gs[1, 1])
        ax3.axis('off')
        
        total_revenue = metrics.get('total_revenue', 0)
        total_products = metrics.get('total_products_sold', 0)
        top_product_info = metrics.get('top_selling_product', {})
        top_product_name = top_product_info.get('name', 'N/A')
        top_product_revenue = top_product_info.get('revenue', 0)
        
        summary_text = f"""
        KEY METRICS
        
        Total Revenue
        ₹{total_revenue:,.2f}
        
        Total Products Sold
        {int(total_products):,} units
        
        Top-Selling Product
        {top_product_name}
        ₹{top_product_revenue:,.2f}
        
        Average Daily Sales
        ₹{total_revenue/len(daily_sales) if len(daily_sales) > 0 else 0:,.2f}
        """
        
        ax3.text(0.1, 0.5, summary_text, fontsize=12, verticalalignment='center',
                bbox=dict(boxstyle='round,pad=1', facecolor='#E8F4F8', edgecolor='#2E86AB', linewidth=2),
                family='monospace', fontweight='bold')
        
        # 4. Product Quantity Sold (bottom left)
        ax4 = fig.add_subplot(gs[2, 0])
        if product_summary is not None and not product_summary.empty:
            sorted_qty = product_summary.sort_values('quantity_sold', ascending=False)
            products = sorted_qty.index
            quantities = sorted_qty['quantity_sold']
            colors = plt.cm.viridis(range(len(products)))
            ax4.pie(quantities, labels=products, autopct='%1.1f%%', startangle=90, colors=colors)
            ax4.set_title('Product Distribution by Quantity', fontsize=14, fontweight='bold')
        
        # 5. Revenue Distribution (bottom right)
        ax5 = fig.add_subplot(gs[2, 1])
        if product_summary is not None and not product_summary.empty:
            sorted_revenue = product_summary.sort_values('total_sales', ascending=False)
            products = sorted_revenue.index
            revenues = sorted_revenue['total_sales']
            colors = plt.cm.plasma(range(len(products)))
            ax5.pie(revenues, labels=products, autopct='%1.1f%%', startangle=90, colors=colors)
            ax5.set_title('Revenue Distribution by Product', fontsize=14, fontweight='bold')
        
        # Save the dashboard
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"✓ Sales dashboard saved to: {save_path}")
        
        plt.close()
        
        return save_path


if __name__ == "__main__":
    # Example usage
    from sales_analyzer import SalesAnalyzer
    
    analyzer = SalesAnalyzer('data/sales_data.csv')
    analyzer.analyze()
    
    visualizer = SalesVisualizer()
    metrics = analyzer.get_summary_dict()
    product_summary = analyzer.get_product_summary()
    
    # Create visualizations
    visualizer.create_daily_sales_chart(metrics['daily_sales'])
    visualizer.create_product_sales_chart(product_summary)
    visualizer.create_dashboard(metrics, product_summary)
