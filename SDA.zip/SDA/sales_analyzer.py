"""
Sales Data Analysis Module
Analyzes store sales data to generate insights and metrics
"""

import pandas as pd
import numpy as np
from datetime import datetime
import os


class SalesAnalyzer:
    """Main class for analyzing sales data"""
    
    def __init__(self, csv_path):
        """
        Initialize the analyzer with a CSV file
        
        Args:
            csv_path: Path to the CSV file containing sales data
        """
        self.csv_path = csv_path
        self.df = None
        self.metrics = {}
        
    def load_data(self):
        """Load and validate the sales data from CSV"""
        try:
            self.df = pd.read_csv(self.csv_path)
            
            # Validate required columns
            required_columns = ['date', 'product_name', 'quantity_sold', 'total_sales']
            missing_columns = [col for col in required_columns if col not in self.df.columns]
            
            if missing_columns:
                raise ValueError(f"Missing required columns: {missing_columns}")
            
            # Convert date column to datetime
            self.df['date'] = pd.to_datetime(self.df['date'])
            
            # Validate numeric columns
            self.df['quantity_sold'] = pd.to_numeric(self.df['quantity_sold'], errors='coerce')
            self.df['total_sales'] = pd.to_numeric(self.df['total_sales'], errors='coerce')
            
            # Remove rows with invalid data
            self.df = self.df.dropna()
            
            print(f"✓ Successfully loaded {len(self.df)} records from {self.csv_path}")
            return True
            
        except FileNotFoundError:
            print(f"✗ Error: File not found - {self.csv_path}")
            return False
        except Exception as e:
            print(f"✗ Error loading data: {str(e)}")
            return False
    
    def calculate_total_revenue(self):
        """Calculate total revenue from all sales"""
        if self.df is None:
            return None
        
        total_revenue = self.df['total_sales'].sum()
        self.metrics['total_revenue'] = total_revenue
        return total_revenue
    
    def calculate_total_products_sold(self):
        """Calculate total number of products sold"""
        if self.df is None:
            return None
        
        total_products = self.df['quantity_sold'].sum()
        self.metrics['total_products_sold'] = total_products
        return total_products
    
    def get_top_selling_product(self):
        """Find the top-selling product by total revenue"""
        if self.df is None:
            return None
        
        # Group by product and sum total sales
        product_sales = self.df.groupby('product_name')['total_sales'].sum()
        top_product = product_sales.idxmax()
        top_product_revenue = product_sales.max()
        
        self.metrics['top_selling_product'] = {
            'name': top_product,
            'revenue': top_product_revenue
        }
        
        return top_product, top_product_revenue
    
    def get_day_wise_sales(self):
        """Calculate day-wise sales trends"""
        if self.df is None:
            return None
        
        # Group by date and sum total sales
        daily_sales = self.df.groupby('date')['total_sales'].sum().sort_index()
        
        self.metrics['daily_sales'] = daily_sales
        return daily_sales
    
    def get_product_summary(self):
        """Get summary statistics for each product"""
        if self.df is None:
            return None
        
        product_summary = self.df.groupby('product_name').agg({
            'quantity_sold': 'sum',
            'total_sales': 'sum'
        }).sort_values('total_sales', ascending=False)
        
        return product_summary
    
    def analyze(self):
        """Run complete analysis and return all metrics"""
        if not self.load_data():
            return None
        
        print("\n" + "="*60)
        print("SALES DATA ANALYSIS REPORT")
        print("="*60)
        
        # Calculate all metrics
        total_revenue = self.calculate_total_revenue()
        total_products = self.calculate_total_products_sold()
        top_product, top_revenue = self.get_top_selling_product()
        daily_sales = self.get_day_wise_sales()
        product_summary = self.get_product_summary()
        
        # Display summary
        print(f"\n📊 OVERALL METRICS")
        print(f"   Total Revenue: ₹{total_revenue:,.2f}")
        print(f"   Total Products Sold: {int(total_products):,} units")
        print(f"   Top-Selling Product: {top_product} (₹{top_revenue:,.2f})")
        
        print(f"\n📈 PRODUCT BREAKDOWN")
        print(product_summary.to_string())
        
        print(f"\n📅 DAILY SALES TREND")
        for date, sales in daily_sales.items():
            print(f"   {date.strftime('%Y-%m-%d')}: ₹{sales:,.2f}")
        
        print("\n" + "="*60)
        
        return self.metrics
    
    def get_summary_dict(self):
        """Return metrics as a dictionary for easy access"""
        return {
            'total_revenue': self.metrics.get('total_revenue', 0),
            'total_products_sold': self.metrics.get('total_products_sold', 0),
            'top_selling_product': self.metrics.get('top_selling_product', {}),
            'daily_sales': self.metrics.get('daily_sales', pd.Series())
        }


if __name__ == "__main__":
    # Example usage
    analyzer = SalesAnalyzer('data/sales_data.csv')
    analyzer.analyze()
