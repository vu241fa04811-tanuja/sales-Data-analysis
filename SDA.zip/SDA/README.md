# Sales Data Analysis Project

A comprehensive Python-based sales data analysis system that processes store sales data and generates actionable insights with visualizations.

## 📋 Overview

This project analyzes sales data from a CSV file to help managers understand:
- **Total Revenue** - Overall sales performance
- **Total Products Sold** - Volume of items sold
- **Top-Selling Product** - Best performing product by revenue
- **Day-wise Sales Trends** - Daily sales patterns and trends
- **Product Performance** - Comparative analysis of all products

## 🚀 Features

- ✅ **Data Validation** - Automatic validation and cleaning of sales data
- ✅ **Comprehensive Metrics** - Calculate key business metrics automatically
- ✅ **Visual Reports** - Generate professional charts and dashboards
- ✅ **Trend Analysis** - Identify sales patterns and trends
- ✅ **Manager Insights** - Actionable insights for decision-making

## 📁 Project Structure

```
SDA/
├── data/
│   └── sales_data.csv          # Sample sales dataset
├── output/
│   ├── daily_sales_chart.png   # Daily sales bar chart
│   ├── product_sales_chart.png # Product comparison chart
│   └── sales_dashboard.png     # Comprehensive dashboard
├── sales_analyzer.py           # Data analysis module
├── sales_visualizer.py         # Visualization module
├── main.py                     # Main application
├── requirements.txt            # Python dependencies
└── README.md                   # This file
```

## 🛠️ Installation

1. **Install Python** (3.8 or higher)

2. **Install Dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

## 📊 Data Format

The CSV file should contain the following columns:
- `date` - Date of sale (YYYY-MM-DD format)
- `product_name` - Name of the product
- `quantity_sold` - Number of units sold
- `total_sales` - Total revenue from the sale

**Example**:
```csv
date,product_name,quantity_sold,total_sales
2026-01-15,Laptop,5,45000
2026-01-15,Mouse,15,3750
```

## 🎯 Usage

### Run Complete Analysis

```bash
python main.py
```

This will:
1. Load and validate the sales data
2. Calculate all metrics
3. Generate visualizations
4. Display manager insights

### Use Individual Modules

**Analysis Only**:
```python
from sales_analyzer import SalesAnalyzer

analyzer = SalesAnalyzer('data/sales_data.csv')
analyzer.analyze()
```

**Visualization Only**:
```python
from sales_visualizer import SalesVisualizer

visualizer = SalesVisualizer()
visualizer.create_daily_sales_chart(daily_sales_data)
```

## 📈 Output

The system generates three main visualizations:

1. **Daily Sales Chart** - Bar graph showing day-by-day sales trends
2. **Product Sales Chart** - Horizontal bar chart comparing product performance
3. **Sales Dashboard** - Comprehensive multi-panel dashboard with:
   - Daily sales trend
   - Product-wise sales comparison
   - Key metrics summary
   - Product distribution by quantity (pie chart)
   - Revenue distribution by product (pie chart)

## 💡 Manager Insights

The system automatically provides:
- Overall revenue and volume metrics
- Star product identification
- Daily average sales
- Best and worst performing days
- Sales trend direction (upward/downward)

## 🔧 Customization

### Add Your Own Data

Replace `data/sales_data.csv` with your own sales data following the same format.

### Modify Visualizations

Edit `sales_visualizer.py` to customize:
- Chart colors and styles
- Layout and dimensions
- Additional metrics or charts

### Extend Analysis

Edit `sales_analyzer.py` to add:
- New metrics calculations
- Custom business logic
- Additional data validations

## 📝 Requirements

- Python 3.8+
- pandas >= 2.0.0
- matplotlib >= 3.7.0
- numpy >= 1.24.0

## 🎓 Example Output

```
SALES DATA ANALYSIS REPORT
============================================================

📊 OVERALL METRICS
   Total Revenue: ₹851,000.00
   Total Products Sold: 514 units
   Top-Selling Product: Laptop (₹432,000.00)

📈 PRODUCT BREAKDOWN
              quantity_sold  total_sales
Laptop                   58       432000
Monitor                  60       240000
Headphones              158        79000
Keyboard                122        61000
Mouse                   165        41250
```

## 🤝 Contributing

Feel free to extend this project with:
- Additional analysis metrics
- More visualization types
- Export to PDF/Excel features
- Web dashboard interface

## 📄 License

This project is open-source and available for educational and commercial use.

---

**Created for**: Sales managers and business analysts
**Purpose**: Quick, actionable insights from sales data
**Level**: Beginner to Intermediate Python
